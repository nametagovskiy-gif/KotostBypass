# Как собрать APK в облаке без установки программ на ПК

1. Открой https://github.com/new и создай репозиторий с названием `KotostBypass`. Можно выбрать Public или Private. Не добавляй README, .gitignore или лицензию при создании.
2. Распакуй архив проекта на компьютере. На странице репозитория нажми `Add file` → `Upload files` и загрузи содержимое папки `KotostBypass` (включая папку `.github`). В корне репозитория должны лежать `settings.gradle`, `build.gradle`, папка `app` и папка `.github`.
3. Нажми `Commit changes`.
4. Открой вкладку `Actions`, выбери `Build Kotost Bypass APK`, затем `Run workflow` → `Run workflow`. Если сборка уже стартовала после загрузки, просто открой её.
5. Дождись зелёной галочки. Внизу страницы сборки в разделе `Artifacts` скачай `KotostBypass-debug-apk` и распакуй архив — внутри будет `app-debug.apk`.

Важно: этот APK — только помощник для настройки Private DNS. Он не реализует полноценный обход DPI/Zapret; Private DNS может не помочь при блокировках YouTube/Discord.
